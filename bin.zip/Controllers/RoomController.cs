using Microsoft.AspNetCore.Mvc;
using WebApp.Models;

public class RoomController : Controller
{
    private readonly ILogger<RoomController> _logger;

    public RoomController(ILogger<RoomController> logger)
    {
        _logger = logger;
    }

    // Index: Zobraz� seznam m�stnost�
    public IActionResult Index()
    {
        var objects = WebApp.Models.Room.ListRooms(); // Z�sk�n� seznamu m�stnost�
        var rooms = new List<Room>();
        foreach (var obj in objects)
        {
            rooms.Add((Room)obj);
        }
        return View(rooms);
    }

    // GET: Room/Create
    [HttpGet]
    public IActionResult Create()
    {
        return View(); // Zobraz� formul�� Create.cshtml
    }

    // POST: Room/Create
    [HttpPost]
    public IActionResult Create(Room room)
    {
        if (ModelState.IsValid)
        {
            // Logika pro p�id�n� nov� m�stnosti
            _logger.LogInformation("New room created successfully.");
            return RedirectToAction("Index");
        }
        return View(room);
    }

    // GET: Room/Edit/5
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var room = Room.GetRoom(id); // Z�sk�n� konkr�tn� m�stnosti podle ID
        if (room == null)
        {
            return NotFound();
        }
        return View(room); // Zobraz� formul�� Edit.cshtml s p�edvypln�n�mi hodnotami
    }

    // POST: Room/Update
    [HttpPost]
    public IActionResult Update(Room updatedRoom)
    {
        if (ModelState.IsValid)
        {
            var existingRoom = Room.GetRoom(updatedRoom.Id);
            if (existingRoom != null)
            {
                // Aktualizace dat existuj�c� m�stnosti
                existingRoom.Name = updatedRoom.Name;
                existingRoom.Capacity = updatedRoom.Capacity;
                existingRoom.Type = updatedRoom.Type;
                existingRoom.Location = updatedRoom.Location;

                _logger.LogInformation("Room updated successfully.");
                return RedirectToAction("Index");
            }
        }
        return View("Edit", updatedRoom); // V p��pad� chyby se vr�t� na editovac� str�nku
    }
}
