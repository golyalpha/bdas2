using Microsoft.AspNetCore.Mvc;
using WebApp.Models;

public class LocationController : Controller
{
    private readonly ILogger<LocationController> _logger;

    public LocationController(ILogger<LocationController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        var locations = WebApp.Models.Location.ListLocations();
        return View(locations);
    }

    // GET: Location/Create
    [HttpGet]
    public IActionResult Create()
    {
        return View(new LocationViewModel());
    }

    // POST: Location/Create
    [HttpPost]
    public IActionResult Create(LocationViewModel locationViewModel)
    {
        if (ModelState.IsValid)
        {
            System.Console.Out.WriteLine(locationViewModel.CityId);
            locationViewModel.Location.City = City.GetCity(locationViewModel.CityId);
            locationViewModel.Location.Persist();
            _logger.LogInformation("New location created successfully.");
            return RedirectToAction("Index");
        }
        return View(locationViewModel);
    }

    // GET: Location/Edit/5
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var location = Location.GetLocation(id); // Z�sk�n� konkr�tn� lokace podle ID
        if (location == null)
        {
            return NotFound();
        }
        return View(location); // Zobraz� formul�� Edit.cshtml s p�edvypln�n�mi hodnotami
    }

    // POST: Location/Update
    [HttpPost]
    public IActionResult Update(Location updatedLocation)
    {
        if (ModelState.IsValid)
        {
            var existingLocation = Location.GetLocation(updatedLocation.Id);
            if (existingLocation != null)
            {
                // Aktualizace dat existuj�c� lokace
                existingLocation.Name = updatedLocation.Name;
                existingLocation.AvailabilityStart = updatedLocation.AvailabilityStart;
                existingLocation.AvailabilityEnd = updatedLocation.AvailabilityEnd;

                _logger.LogInformation("Location updated successfully.");
                return RedirectToAction("Index");
            }
        }
        return View("Edit", updatedLocation); // V p��pad� chyby se vr�t� na editovac� str�nku
    }
}