using Microsoft.AspNetCore.Mvc;
using WebApp.Models;

public class RequestController : Controller
{
    private readonly ILogger<RequestController> _logger;

    public RequestController(ILogger<RequestController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        var requests = WebApp.Models.Request.ListRequests(); // Z�sk�n� seznamu ��dost� pro zobrazen� v indexu
        return View(requests);
    }

    // GET: Request/Create
    [HttpGet]
    public IActionResult Create()
    {
        return View(); // Zobraz� formul�� Create.cshtml
    }

    // POST: Request/Create
    [HttpPost]
    public IActionResult Create(Request request)
    {
        if (ModelState.IsValid)
        {
            // Logika pro p�id�n� nov� ��dosti (nap��klad ukl�d�n� do datab�ze)
            _logger.LogInformation("New request created successfully.");
            return RedirectToAction("Index");
        }
        return View(request);
    }

    // GET: Request/Edit/5
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var request = WebApp.Models.Request.GetRequest(id); // Z�sk�n� konkr�tn� ��dosti podle ID
        if (request == null)
        {
            return NotFound();
        }
        return View(request); // Zobraz� formul�� Edit.cshtml s p�edvypln�n�mi hodnotami
    }

    // POST: Request/Update
    [HttpPost]
    public IActionResult Update(Request updatedRequest)
    {
        if (ModelState.IsValid)
        {
            var existingRequest = (Request)WebApp.Models.Request.GetRequest(updatedRequest.Id);
            if (existingRequest != null)
            {
                // Aktualizace dat existuj�c� ��dosti
                existingRequest.Start = updatedRequest.Start;
                existingRequest.End = updatedRequest.End;
                existingRequest.Organiser = updatedRequest.Organiser;

                _logger.LogInformation("Request updated successfully.");
                return RedirectToAction("Index");
            }
        }
        return View("Edit", updatedRequest); // V p��pad� chyby se vr�t� na editovac� str�nku
    }
}
